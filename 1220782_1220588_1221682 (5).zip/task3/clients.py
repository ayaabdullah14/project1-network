import socket
import threading
import time
import sys
import re
class GameClient:
    def __init__(self):  # Initializes the client
        self.tcp_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.running = True
        self.game_active = False
        self.server_ip = None
        self.udp_port = None
        self.cooldown = 10  # Reducing the cooldown between guesses from 10 to 2 seconds
#---------------------------------------------------
# Connects to the server by obtaining the server IP and port
    def connect_to_server(self):
        print("\n=== Number Guessing Game Client ===")
        
        # Get server info
        while True:
            server_ip = input("Enter server IP: ").strip()
            if re.match(r"^\d{1,3}(\.\d{1,3}){3}$", server_ip):
                break
            print("Invalid IP address format. Try again.")

        while True:
            try:
                tcp_port = int(input("Enter TCP port : ").strip() or "6000")
                udp_port = int(input("Enter UDP port : ").strip() or "6001")
                break
            except ValueError:
                print("Port must be a number. Try again.")

        print(f"\nConnecting to server at {server_ip}...")
        try:
            # Connect to server
            self.tcp_socket.connect((server_ip, tcp_port))
            self.server_ip = server_ip
            self.udp_port = udp_port
            print("Connected to server!")
            
            # Configure UDP socket to be non-blocking
            self.udp_socket.settimeout(5)  # 5 second timeout for UDP responses
            
            return True
            
        except ConnectionRefusedError:
            print(f"Error: Could not connect to server at {server_ip}:{tcp_port}")
            return False
        except Exception as e:
            print(f"Error connecting to server: {str(e)}")
            return False
        #----------------------------------
        # Listens for TCP messages from the server and processes responses
    def listen_tcp(self):
        """Listen for TCP messages from server"""
        while self.running:
            try:
                msg = self.tcp_socket.recv(1024).decode()
                if not msg:
                    print("Connection to server lost.")
                    self.running = False
                    break
                        
                print(f"\n[SERVER] {msg}")
                    
                if "Game started" in msg or "guess the number" in msg.lower():
                    self.game_active = True
                    print("[INFO] Game is active! You can now send guesses.")
                    
                elif "won the round" in msg or "Time's up" in msg:
                    print("[INFO] Round ended. Waiting for next round...")
                    self.game_active = False
                    
                elif "Do you want to continue playing alone" in msg:
                    response = input("\nYou are the last player. Continue playing alone? (yes/no): ").strip().lower()
                    self.tcp_socket.send(response.encode())
                    
                    if response != "yes":
                        print("Exiting game...")
                        self.running = False
                        break
                        
            except ConnectionResetError:
                print("\nServer connection closed.")
                self.running = False
                break
            except ConnectionAbortedError:
                print("\nServer connection aborted.")
                self.running = False
                break
            except socket.error as se:
                print(f"\n[ERROR] Socket error: {se}")
                self.running = False
                break
            except Exception as e:
                print(f"\n[ERROR] Unexpected error: {str(e)}")
                self.running = False
                break
#-----------------------------------------------------------------
# Sends guesses to the server via UDP
    def send_guesses(self):
        """Send guesses to server via UDP"""
        while self.running:
            try:
                if self.game_active:
                    guess = input("\nEnter your guess (1-100) or 'exit' to quit: ").strip()
                    
                    if not self.running:
                        break
                    
                    if guess.lower() == 'exit':
                        print("Exiting game...")
                        self.running = False
                        break
                        
                    try:
                        guess_num = int(guess)
                        if 1 <= guess_num <= 100:
                            print(f"Sending guess: {guess_num}")
                            self.udp_socket.sendto(guess.encode(), (self.server_ip, self.udp_port))
                            
                            try:
                                # Get UDP response
                                response, _ = self.udp_socket.recvfrom(1024)
                                response_text = response.decode()
                                print(f"[SERVER] {response_text}")
                                
                                if "Correct" in response_text:
                                    print("Congratulations! You guessed correctly!")
                                
                                if self.cooldown > 0:
                                    print(f"Waiting for {self.cooldown} seconds before next guess...")
                                    time.sleep(self.cooldown)
                                    
                            except socket.timeout:
                                print("No response from server. Try again.")
                                
                        else:
                            print("Number must be between 1-100. Try again.")
                    except ValueError:
                        print("Please enter a valid number.")
                else:
                    # If game is not active, wait a bit before checking again
                    time.sleep(0.5)
            except KeyboardInterrupt:
                print("\nInterrupted by user.")
                self.running = False
                break
            except Exception as e:
                print(f"Error sending guess: {str(e)}")
                time.sleep(1)  # Wait before trying again
#---------------------------------------------------------------------
# loop to connect to the server,
    def run(self):
        """Main client loop"""
        try:
            # Connect to server
            if not self.connect_to_server():
                print("Failed to connect to server. Exiting.")
                return
            
            # Process welcome message and name registration
            welcome = self.tcp_socket.recv(1024).decode()
            print(f"[SERVER] {welcome}")

            # Send player name
            name = input("Enter your name: ").strip()
            self.tcp_socket.send(name.encode())

            # Get registration response
            response = self.tcp_socket.recv(1024).decode()
            print(f"[SERVER] {response}")
            
            # Start TCP listener thread
            tcp_thread = threading.Thread(target=self.listen_tcp)
            tcp_thread.daemon = True
            tcp_thread.start()
            
            # Start guessing loop
            self.send_guesses()
            
        except KeyboardInterrupt:
            print("\nExiting...")
        except Exception as e:
            print(f"\nError: {str(e)}")
        finally:
            self.cleanup()

    def cleanup(self):
        """Clean up resources"""
        self.running = False
        try:
            self.tcp_socket.close()
            self.udp_socket.close()
        except:
            pass
        print("\nDisconnected from server. Goodbye!")

if __name__ == "__main__":
    client = GameClient()
    client.run()