import socket
import threading
import time
import random

# Server configuration
SERVER_HOST = '0.0.0.0'
TCP_PORT = 6000
UDP_PORT = 6001
GUESS_RANGE = (1, 100)
MIN_PLAYERS = 2
MAX_PLAYERS = 4
ROUND_DURATION = 60  # round time in seconds
# Get the server's IP address
hostname = socket.gethostname()
server_ip = socket.gethostbyname(hostname)
print(f"[SERVER] Server IP Address: {server_ip}")

players = {}  # Dictionary to hold player name and TCP connection
player_addresses = {}  # Map player names to (IP, UDP_port)
secret_number = None
game_active = False
start_time = None
round_timer = None
server_running = True
# Set up the TCP server socket
server_TCP_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_TCP_socket.bind((SERVER_HOST, TCP_PORT))
server_TCP_socket.listen()
print(f"[TCP] Listening on port {TCP_PORT}...")
# Set up the UDP server socket
server_UDP_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
server_UDP_socket.bind((SERVER_HOST, UDP_PORT))
print(f"[UDP] Listening for guesses on port {UDP_PORT}...")

 # Function to handling TCP and UDP Connections
def handle_connections(protocol):
    if protocol == 'TCP': # Handling TCP Connections
        while server_running:
            try:
                conn, addr = server_TCP_socket.accept()
                threading.Thread(target=handle_client_tcp, args=(conn, addr), daemon=True).start()
            except Exception as e:
                if server_running:  # Only log errors if server is supposed to be running
                    print(f"[TCP ERROR] {str(e)}")
    elif protocol == 'UDP': # Handling UDP Connections
        while server_running:
            try:
                data, addr = server_UDP_socket.recvfrom(1024)
                threading.Thread(target=handle_client_udp, args=(data, addr), daemon=True).start()
            except Exception as e:
                if server_running:  # Only log errors if server is supposed to be running
                    print(f"[UDP ERROR] {str(e)}")
                
# Function to handle a TCP client connection
def handle_client_tcp(conn, addr):
    global secret_number, game_active, start_time
    name = None
    try:
        conn.send(b"Welcome! Please enter your name (e.g. Player_1=Last_First): ")
        name_data = conn.recv(1024)
        if not name_data:
            conn.close()
            return

        name = name_data.decode().strip()

        if name in players:
            conn.send(b"Name already used. Try again.\n")
            conn.close()
            return

        if len(players) >= MAX_PLAYERS:
            conn.send(b"Maximum number of players reached.\n")
            conn.close()
            return

        players[name] = conn
        player_addresses[name] = addr[0]  # Store just the IP, not the port since UDP port is different
        print(f"[TCP] {name} joined from {addr[0]}")

        if len(players) < MIN_PLAYERS:
            conn.send(b"Registered. Waiting for more players to join...\n")
        else:
            conn.send(b"Registered. Game is about to start or already started.\n")

        if len(players) >= MIN_PLAYERS and not game_active:
            threading.Thread(target=start_game, daemon=True).start()

        if game_active:
            conn.sendall(f"Game in progress! You can start guessing between {GUESS_RANGE[0]} and {GUESS_RANGE[1]} via UDP port {UDP_PORT}.\n".encode())

        # Keep connection open to receive game updates
        while server_running:
            try:
                data = conn.recv(1024)
                if not data:
                    raise ConnectionError("Connection closed")
                
                # Handle any additional TCP commands here if needed
                
            except Exception:
                print(f"[DISCONNECT] {name} disconnected")
                if name in players:
                    del players[name]
                if name in player_addresses:
                    del player_addresses[name]
                conn.close()
                check_players_after_leave()
                break

    except Exception as e:
        print(f"[ERROR] Connection lost with {addr}: {str(e)}")
        if name and name in players:
            del players[name]
        if name and name in player_addresses:
            del player_addresses[name]
        conn.close()
        check_players_after_leave()


# Function to check the players' status
def check_players_after_leave():
    global game_active, secret_number
    
    if len(players) == 1 and game_active:
        only_name = list(players.keys())[0]
        only_conn = players[only_name]
        try:
            only_conn.sendall(b"You are the last player. Do you want to continue playing alone? (yes/no): ")
            response = only_conn.recv(1024).decode().strip().lower()
            if response == 'yes':
                only_conn.sendall(b"You will continue playing alone.\n")
            else:
                only_conn.sendall(b"Game ended.\n")
                only_conn.close()
                del players[only_name]
                del player_addresses[only_name]
                end_game()
        except Exception as e:
            print(f"[ERROR] Could not communicate with {only_name}: {e}")
            
    elif len(players) == 0 and game_active:
        print("[INFO] No players remaining. Ending game.")
        end_game()

# Function to handle UDP client guesses
def handle_client_udp(data, addr):
    global secret_number, game_active, start_time
    
    if not game_active or secret_number is None:
        server_UDP_socket.sendto(b"No active game round. Wait for the next round to start.", addr)
        return

    # Check if the round time is up
    time_elapsed = time.time() - start_time
    if time_elapsed >= ROUND_DURATION:
        end_round_by_timeout()
        server_UDP_socket.sendto(b"Time's up! Round has ended.", addr)
        return

    # Process the guess
    try:
        guess = int(data.decode().strip())
    except ValueError:
        server_UDP_socket.sendto(b"Invalid input. Send a number.", addr)
        return

    # Find which player made this guess by IP address
    player_name = "Unknown"
    for name, ip in player_addresses.items():
        if ip == addr[0]:
            player_name = name
            break
    
    print(f"[UDP] Guess {guess} from {player_name} ({addr[0]})")

    if guess < secret_number:
        server_UDP_socket.sendto(b"Higher", addr)
    elif guess > secret_number:
        server_UDP_socket.sendto(b"Lower", addr)
    else:
        server_UDP_socket.sendto(b"Correct!", addr)
        announce_winner(player_name)

# Function to start a new game round
def start_game():
    global secret_number, game_active, start_time, round_timer
    
    # Cancel any existing timer
    if round_timer:
        round_timer.cancel()
    
    secret_number = random.randint(*GUESS_RANGE)
    game_active = True
    start_time = time.time()
    print(f"[GAME] Starting the game. Secret number is {secret_number}")

    message = f"Game started! Guess the number between {GUESS_RANGE[0]} and {GUESS_RANGE[1]}.\n"
    message += f"You have {ROUND_DURATION} seconds. Send your guesses via UDP to port {UDP_PORT}.\n"

    for name, conn in players.items():
        try:
            conn.sendall(message.encode())
        except Exception as e:
            print(f"[TCP] Could not notify {name}: {e}")

    # Start the round timer
    round_timer = threading.Timer(ROUND_DURATION, end_round_by_timeout)
    round_timer.daemon = True
    round_timer.start()

# Function to announce the winner of the game round
def announce_winner(winner_name):
    global game_active
    
    if not game_active:  # Prevent race conditions
        return
        
    print(f"[WINNER] {winner_name} guessed correctly!")
    message = f"{winner_name} won the round by guessing the correct number! The number was {secret_number}.\n".encode()
    
    for name, conn in players.items():
        try:
            conn.sendall(message)
        except Exception as e:
            print(f"[TCP] Could not notify {name}: {e}")

    end_game()
    
    # Wait a moment before starting a new game
    threading.Timer(3, start_new_game).start()
    #-----------------------------------------------------------------------------
    # Function to end the round if the time limit is reached
def end_round_by_timeout():
    global game_active
    
    if not game_active:  # Prevent race conditions
        return
        
    print("[TIMEOUT] Round ended: time limit reached. No winner.")
    message = f"Time's up! No winner this round. The correct number was {secret_number}.\n".encode()
    
    for name, conn in players.items():
        try:
            conn.sendall(message)
        except Exception as e:
            print(f"[TCP] Could not notify {name}: {e}")

    end_game()
    
    # Wait a moment before starting a new game
    threading.Timer(3, start_new_game).start()
#----------------------------------------------------------------------------------
# Function to end the game
def end_game():
    global game_active, secret_number, round_timer
    game_active = False
    secret_number = None
    
    # Cancel the round timer if it exists
    if round_timer:
        round_timer.cancel()
        round_timer = None
#----------------------------------------------------------------------------------
# Function to start a new game 

def start_new_game():
    if len(players) >= MIN_PLAYERS:
        start_game()
    else:
        print(f"[GAME] Not enough players ({len(players)}/{MIN_PLAYERS}) to start a new game.")
        notify_waiting_for_players()
#----------------------------------------------------------------------------------
# Function to notify players that more players are needed to start the game
def notify_waiting_for_players():
    message = f"Waiting for more players to join. Need at least {MIN_PLAYERS} players.\n".encode()
    
    for name, conn in players.items():
        try:
            conn.sendall(message)
        except Exception as e:
            print(f"[TCP] Could not notify {name}: {e}")

# Start handling connections
tcp_thread = threading.Thread(target=handle_connections, args=('TCP',), daemon=True)
udp_thread = threading.Thread(target=handle_connections, args=('UDP',), daemon=True)
tcp_thread.start()
udp_thread.start()

print("[SERVER] Server is running...")

try:
    while True:
        time.sleep(1)
except KeyboardInterrupt:
    print("\n[SERVER] Shutting down...")
    server_running = False
    server_TCP_socket.close()
    server_UDP_socket.close()