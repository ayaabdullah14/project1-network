import os
import socket
from urllib.parse import parse_qs, urlparse
import logging
from typing import Tuple, Optional, Dict

# Configure logging
logging.basicConfig(
    level=logging.DEBUG,
    format='[%(asctime)s] %(levelname)s: %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)

# Configuration
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
HTML_DIR = os.path.join(BASE_DIR, 'html')
IMAGES_DIR = os.path.join(BASE_DIR, 'images')
VIDEOS_DIR = os.path.join(BASE_DIR, 'videos')
SERVER_PORT = 9958
SERVER_HOST = '0.0.0.0'
MAX_REQUEST_SIZE = 4096
DEFAULT_ERROR_MESSAGE = "<html><body><h1>{status_code} {reason}</h1></body></html>"

# Ensure directories exist
os.makedirs(HTML_DIR, exist_ok=True)
os.makedirs(IMAGES_DIR, exist_ok=True)
os.makedirs(VIDEOS_DIR, exist_ok=True)

STATUS_REASONS = {
    200: "OK",
    307: "Temporary Redirect",
    400: "Bad Request",
    404: "Not Found",
    500: "Internal Server Error"
}

# Content types
CONTENT_TYPES = {
    'html': 'text/html',
    'css': 'text/css',
    'js': 'application/javascript',
    'jpg': 'image/jpeg',
    'jpeg': 'image/jpeg',
    'png': 'image/png',
    'gif': 'image/gif',
    'mp4': 'video/mp4',
    'webm': 'video/webm',
    'ico': 'image/x-icon',
    'svg': 'image/svg+xml',
    'json': 'application/json',
    'txt': 'text/plain'
}

def get_safe_path(base_dir: str, *path_parts: str) :
    try:
        requested_path = os.path.abspath(os.path.join(base_dir, *path_parts))
        base_path = os.path.abspath(base_dir)
        if os.path.commonpath([base_path]) == os.path.commonpath([base_path, requested_path]):
            return requested_path
        return None
    except Exception:
        return None

def get_content_type(filename: str):
    ext = filename.split('.')[-1].lower()
    return CONTENT_TYPES.get(ext, 'application/octet-stream')

def send_response(
    connection: socket.socket,
    status_code: int,
    content_type: str = 'text/html',
    content: bytes = b'',
    headers: Optional[Dict[str, str]] = None
) :
    try:
        reason = STATUS_REASONS.get(status_code, "Unknown Status")
        if content_type.startswith("text/") or content_type == "application/javascript":
            content_type += "; charset=UTF-8"

        response = f"HTTP/1.1 {status_code} {reason}\r\n"
        response += f"Content-Type: {content_type}\r\n"
        response += f"Content-Length: {len(content)}\r\n"

        if headers:
            for key, value in headers.items():
                response += f"{key}: {value}\r\n"

        response += "\r\n"

        connection.sendall(response.encode('utf-8'))
        if content:
            connection.sendall(content)

    except Exception as e:
        print(f"Error sending response: {e}")
        try:
            connection.close()
        except:
            pass

def send_error(connection: socket.socket, status_code: int) :
    try:
        error_message = DEFAULT_ERROR_MESSAGE.format(
            status_code=status_code,
            reason=STATUS_REASONS.get(status_code, "Error")
        ).encode('utf-8')
        send_response(connection, status_code, 'text/html; charset=UTF-8', error_message)
    finally:
        connection.close()

def serve_file(connection: socket.socket, filename: str, base_dir: str):
    try:
        filepath = get_safe_path(base_dir, filename)
        if not filepath or not os.path.exists(filepath):
            logging.warning(f"File not found: {filename} in {base_dir}")
            send_error(connection, 404)
            return

        content_type = get_content_type(filename)
        mode = 'rb' if content_type.startswith(('image/', 'video/')) else 'r'
        encoding = None if content_type.startswith(('image/', 'video/')) else 'utf-8'

        with open(filepath, mode, encoding=encoding) as f:
            content = f.read()
            if mode == 'r':
                content = content.encode('utf-8')

        send_response(connection, 200, content_type, content)
        logging.info(f"Served file: {filename}")

    except PermissionError:
        logging.error(f"Permission denied for file: {filename}")
        send_error(connection, 403)
    except Exception as e:
        logging.error(f"Error serving file {filename}: {e}")
        send_error(connection, 500)

def handle_form_request(connection: socket.socket, query: dict) :
    try:
        material = query.get('material', [''])[0]
        material_type = query.get('type', [''])[0]

        if not material or not material_type:
            logging.warning("Missing form parameters")
            send_error(connection, 400)
            return

        logging.info(f"Form request - material: {material}, type: {material_type}")

        if material_type == 'image':
            found = False
            for ext in ['jpg', 'jpeg', 'png', 'gif']:
                filename = f"{material}.{ext}"
                filepath = get_safe_path(IMAGES_DIR, filename)
                if filepath and os.path.exists(filepath):
                    serve_file(connection, filename, IMAGES_DIR)
                    found = True
                    break

            if not found:
                query_encoded = material.replace(" ", "+")
                redirect_url = f"https://www.google.com/search?q={query_encoded}&tbm=isch"
                headers = {'Location': redirect_url}
                send_response(connection, 307, 'text/html; charset=UTF-8', b'', headers=headers)
                logging.info(f"Redirecting to Google Images for: {material}")

        elif material_type == 'video':
            filename = f"{material}.mp4"
            filepath = get_safe_path(VIDEOS_DIR, filename)
            if filepath and os.path.exists(filepath):
                serve_file(connection, filename, VIDEOS_DIR)
            else:
                query_encoded = material.replace(" ", "+")
                redirect_url = f"https://www.youtube.com/results?search_query={query_encoded}"
                headers = {'Location': redirect_url}
                send_response(connection, 307, 'text/html; charset=UTF-8', b'', headers=headers)
                logging.info(f"Redirecting to YouTube for: {material}")
        else:
            logging.warning(f"Invalid material type: {material_type}")
            send_error(connection, 400)

    except Exception as e:
        logging.error(f"Error handling form request: {e}")
        send_error(connection, 500)

def handle_request(connection: socket.socket, ip: str, port: int, request: str) :
    try:
        request_line = request.split('\n')[0].strip()
        parts = request_line.split()

        if len(parts) < 3:
            logging.warning(f"Malformed request line: {request_line}")
            send_error(connection, 400)
            return

        method, path, protocol = parts
        logging.info(f"Request: {method} {path} from {ip}:{port}")

        parsed = urlparse(path)
        path = parsed.path
        query = parse_qs(parsed.query)

        if path in ["/", "/index.html", "/main_en.html", "/en"]:
            serve_file(connection, 'main_en.html', HTML_DIR)
        elif path in ["/ar", "/main_ar.html"]:
            serve_file(connection, 'main_ar.html', HTML_DIR)
        elif path == "/mySite_1220588_en.html":
            serve_file(connection, 'mySite_1220588_en.html', HTML_DIR)
        elif path == "/mySite_1220588_ar.html":
            serve_file(connection, 'mySite_1220588_ar.html', HTML_DIR)
        elif path.startswith("/images/"):
            filename = path.split('/')[-1]
            serve_file(connection, filename, IMAGES_DIR)
        elif path.startswith("/videos/"):
            filename = path.split('/')[-1]
            serve_file(connection, filename, VIDEOS_DIR)
        elif path == "/request_handler":
            handle_form_request(connection, query)
        else:
            filename = path.lstrip('/')
            if '.' in filename:
                ext = filename.split('.')[-1].lower()
                if ext in ['html', 'css', 'js']:
                    serve_file(connection, filename, HTML_DIR)
                elif ext in ['jpg', 'jpeg', 'png', 'gif', 'svg', 'ico']:
                    serve_file(connection, filename, IMAGES_DIR)
                elif ext in ['mp4', 'webm']:
                    serve_file(connection, filename, VIDEOS_DIR)
                else:
                    serve_file(connection, filename, BASE_DIR)
            else:
                logging.warning(f"File not found: {path}")
                send_error(connection, 404)

    except Exception as e:
        logging.error(f"Error handling request: {e}")
        send_error(connection, 500)

def run_server() :
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_socket:
        server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server_socket.bind((SERVER_HOST, SERVER_PORT))
        server_socket.listen(5)
        server_socket.settimeout(1)

        logging.info(f"Server started on {SERVER_HOST}:{SERVER_PORT}")
        logging.info(f"HTML directory: {HTML_DIR}")
        logging.info(f"Images directory: {IMAGES_DIR}")
        logging.info(f"Videos directory: {VIDEOS_DIR}")

        try:
            while True:
                try:
                    connection, (ip, port) = server_socket.accept()
                    logging.debug(f"New connection from {ip}:{port}")

                    with connection:
                        request = connection.recv(MAX_REQUEST_SIZE).decode('utf-8')
                        if not request:
                            logging.debug("Empty request received")
                            continue

                        handle_request(connection, ip, port, request)

                except socket.timeout:
                    continue
                except Exception as e:
                    logging.error(f"Error handling connection: {e}")

        except KeyboardInterrupt:
            logging.info("Server shutting down...")
        finally:
            logging.info("Server stopped")

if __name__ == "__main__":
    run_server()